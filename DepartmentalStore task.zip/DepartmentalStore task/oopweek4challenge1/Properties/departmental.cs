﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace oopweek4challenge1.Properties
{
    class departmental
    {
        public departmental()
        {

        }
        public departmental(ref string Productname, ref string Productcatagory, ref float Price, ref int Stockquantity)
        {
            productname = Productname;
            productcatagory = Productcatagory;
            price = Price;
            stockquantity = Stockquantity;
        }

        public departmental(string Productname, float Price)
        {
            productname = Productname;
            price = Price;
        }
        public void addproduct(List<departmental> s, departmental p)
        {
            s.Add(p);
        }
        public void viewproduct(List<departmental> s)
        {
            for (int j = 0; j < s.Count(); j++)
            {
                Console.WriteLine("PRODUCT NAME :{0} PRODUCT CATAGORY :{1} PRODUCT PRICE :{2} PRODUCT STOCK :{3}", s[j].productname, s[j].productcatagory, s[j].price, s[j].stockquantity);
                Console.WriteLine("Press any where to continue");
                Console.ReadKey();

            }

        }
        public void highestprice(List<departmental> s, departmental p, ref float temp)
        {
            string temp1 = "";
            string temp2 = "";
            int temp3 = 0;
            int i = 0;

            while (i < s.Count())
            {
                for (int j = 0; j < s.Count(); j++)
                {

                    if (s[i].price < s[j].price)
                    {
                        temp1 = s[j].productname;
                        temp2 = s[j].productcatagory;
                        temp = s[j].price;
                        temp3 = s[j].stockquantity;

                    }
                }
                i++;
            }
            Console.WriteLine("PRODUCT NAME :{0} PRODUCT CATAGORY :{1} PRODUCT PRICE :{2} PRODUCT STOCK :{3}", temp1, temp2, temp, temp3);
        }
        public void tax(List<departmental> s, ref float tax)
        {

            float nowtotal = 0;
            for (int j = 0; j < s.Count(); j++)
            {
                if (s[j].productcatagory == "g")
                {
                    tax = s[j].price * 10 / 100;
                    nowtotal = s[j].price + tax;
                }
                else if (s[j].productcatagory == "f")
                {
                    tax = s[j].price * 5 / 100;
                    nowtotal = s[j].price + tax;

                }
                else
                {
                    tax = s[j].price * 15 / 100;
                    nowtotal = s[j].price + tax;

                }
                Console.WriteLine("PRODUCT NAME :{0} PRODUCT CATAGORY :{1} PRODUCT PRICE :{2} PRODUCT STOCK :{3} TAX :{4} NOW TOTAL MONEY :{5}", s[j].productname, s[j].productcatagory, s[j].price, s[j].stockquantity, tax, nowtotal);
                Console.WriteLine("Press any where to continue");
                Console.ReadKey();

            }
        }
        public void threshold(List<departmental> s)
        {
            string temp1 = "";
            string temp2 = "";
            float temp3 = 0;
            int temp4 = 0;

            for (int j = 0; j < s.Count(); j++)
            {
                if (s[j].stockquantity < 6)
                {
                    temp1 = s[j].productname;
                    temp2 = s[j].productcatagory;
                    temp3 = s[j].price;
                    temp4 = s[j].stockquantity;

                    Console.WriteLine("PRODUCT NAME :{0} PRODUCT CATAGORY :{1} PRODUCT PRICE :{2} PRODUCT STOCK :{3}", temp1, temp2, temp3, temp4);
                    Console.WriteLine("FOLLOWING PRODUCTS SHOULD BE ORDERED SOON");
                    Console.ReadKey();
                }
            }
        }
        public bool checkproductname(List<departmental> s,ref string Productname,ref string Productcatagory,ref float Price,ref int Stockquantity)
        {
            bool foundName = false;
            for(int j =0; j < s.Count(); j++)
            {
                if (Productname == s[j].productname) 
                {
                    s[j].price = Price;
                    s[j].stockquantity = s[j].stockquantity + Stockquantity;
                    foundName = true;
                }
            }
            return foundName;
        }
        public int checkpProductupdate(List<departmental> s,ref string Productname)
        {
            for (int j = 0; j < s.Count(); j++)
            {
                if (Productname == s[j].productname)
                {
                    return j;
                }
            } 
            return -1;
        }
        public int checkpProductdelete(List<departmental> s, ref string Productname)
        {
            for (int j = 0; j < s.Count(); j++)
            {
                if (Productname == s[j].productname)
                {
                    return j; 
                }
            }
            return -1;
        }

        public departmental(ref string Productname, ref float Price)
        {
            productname = Productname;
            price = Price;
        }
        public string productname;
        public string productcatagory;
        public float price;
        public int stockquantity;
    }
}
