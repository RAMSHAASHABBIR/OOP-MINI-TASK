﻿using oopweek4challenge1.Properties;
using System;
using System.Collections.Generic;
using System.IO;

namespace oopweek4challenge1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string choice = "";
            float temp = 0;
            string Productname = "";
            string Productcatagory = "";
            float Price = 0;
            float tax = 10;
            int Stockquantity = 0;
            List<departmental> s = new List<departmental>();
            string path = "E:\\oopweek5labdepartment\\store";
            readDatacrud(path, s, ref Productname, ref Productcatagory, ref Price, ref Stockquantity);
            List<MUser> users = new List<MUser>();
            string path1 = "E:\\oopweek5labdepartment\\store1";
            int option;
            bool check = readData(path1, users);
            if (check)
                Console.WriteLine("Data Loaded SuccessFully");
            else
                Console.WriteLine("Data Not Loaded");
            Console.ReadKey();
            do
            {
                Console.Clear();
                option = menu();
                Console.Clear();
                if (option == 1)
                {
                    MUser user = takeInputWithoutRole();
                    if (user != null)
                    {
                        user = signIn(user, users);
                        if (user == null)
                            Console.WriteLine("Invalid User uu");
                        else if (user.isAdmin())
                        {
                            Console.Clear();
                            do
                            {
                                showAdminMainMenu();
                                choice = adminMainMenu();

                                if (choice == "1")
                                {
                                    Console.Clear();
                                    Console.WriteLine("Enter product name :");
                                    Productname = Console.ReadLine();
                                    Console.WriteLine("Enter productcatagory name :");
                                    Productcatagory = Console.ReadLine();
                                    Console.WriteLine("Enter product price :");
                                    Price = float.Parse(Console.ReadLine());
                                    Console.WriteLine("Enter product stock quantity :");
                                    Stockquantity = int.Parse(Console.ReadLine());
                                    departmental p = new departmental(ref Productname, ref Productcatagory, ref Price, ref Stockquantity);
                                    bool check1 = p.checkproductname(s, ref Productname, ref Productcatagory, ref Price, ref Stockquantity);
                                    if (check1 == false)
                                    {
                                        p.addproduct(s, p);
                                        writeinfilecrud(s);
                                    }
                                    else
                                    {
                                        writeinfilecrud(s);
                                    }
                                    Console.ReadKey();
                                    Console.Clear();

                                }
                                else if (choice == "2")
                                {
                                    Console.Clear();
                                    departmental p1 = new departmental(ref Productname, ref Productcatagory, ref Price, ref Stockquantity);
                                    p1.viewproduct(s);
                                    Console.ReadKey();
                                    Console.Clear();
                                    writeinfilecrud(s);
                                }
                                else if (choice == "3")
                                {
                                    Console.Clear();
                                    departmental p2 = new departmental(ref Productname, ref Productcatagory, ref Price, ref Stockquantity);
                                    Console.WriteLine("Highest unit price product is :");
                                    p2.highestprice(s, p2, ref temp);
                                    Console.ReadKey();
                                    Console.Clear();
                                }
                                else if (choice == "4")
                                {
                                    Console.Clear();
                                    departmental p3 = new departmental(ref Productname, ref Productcatagory, ref Price, ref Stockquantity);
                                    p3.tax(s, ref tax);
                                    Console.ReadKey();
                                    Console.Clear();
                                }
                                else if (choice == "5")
                                {
                                    Console.Clear();
                                    departmental p4 = new departmental(ref Productname, ref Productcatagory, ref Price, ref Stockquantity);
                                    p4.threshold(s);
                                    Console.ReadKey();
                                    Console.Clear();
                                }
                                else if (choice == "6")
                                {
                                    Console.Clear();
                                    Console.WriteLine("Enter product name :");
                                    Productname = Console.ReadLine();
                                    departmental dept = new departmental();
                                    int flag = dept.checkpProductupdate(s, ref Productname);
                                    if (flag == -1)
                                    {
                                        Console.WriteLine("PRODUCT NOT FOUND");

                                    }
                                    else
                                    {
                                        Console.WriteLine("Enter product name :");
                                        s[flag].productname = Console.ReadLine();
                                        Console.WriteLine("Enter product price :");
                                        s[flag].price = float.Parse(Console.ReadLine());
                                    }
                                    Console.ReadKey();
                                    Console.Clear();
                                    writeinfilecrud(s);
                                }
                                else if (choice == "7")
                                {
                                    Console.Clear();
                                    Console.WriteLine("Enter product name :");
                                    Productname = Console.ReadLine();
                                    departmental dept1 = new departmental();
                                    int flag = dept1.checkpProductdelete(s, ref Productname);
                                    if (flag == -1)
                                    {
                                        Console.WriteLine("PRODUCT NOT FOUND");

                                    }
                                    else
                                    {

                                        s[flag].productname = Console.ReadLine();
                                        s.RemoveAt(flag);
                                        writeinfilecrud(s);
                                    }
                                }
                               
                            }
                            while (choice != "8");
                        }
                        else
                            Console.WriteLine("User Menu");
                    }
                }
                else if (option == 2)
                {

                    MUser userq = takeInputWithRole();
                    if (userq != null)
                    {
                        storeDataInList(users, userq);
                        storeDataInFile(path1, users);
                      
                    } 
                }
                else
                    Console.WriteLine("dafa");
                Console.ReadKey();

            }
            while (option < 3);

        }

        static void showAdminMainMenu()
        {

            Console.WriteLine("Select one of the option from 1 to 5");
            Console.WriteLine("  1.ADD PRODUCTS");
            Console.WriteLine("  2.VIEW PRODUCTS");
            Console.WriteLine("  3.HIGHEST UNIT PRICE");
            Console.WriteLine("  4.VIEW PRODUCT INCLUDING TAX");
            Console.WriteLine("  5.PRODUCTS TO BE ORDERED SOON");
            Console.WriteLine("  6.UPDATE PRODUCT");
            Console.WriteLine("  7.DELETE PRODUCT");
            Console.WriteLine("  8.PRESS 8 TO GO TO EXIT");
        }
        static string adminMainMenu()
        {
            string chosing = "";

            chosing = Console.ReadLine();
            return chosing;
        }
        static void writeinfilecrud(List<departmental> s)
        {
            string path = "E:\\oopweek5labdepartment\\store";
            StreamWriter fileVariable = new StreamWriter(path);
            for (int i = 0; i < s.Count; i++)
            {
                fileVariable.WriteLine(s[i].productname + "," + s[i].productcatagory + "," + s[i].price + "," + s[i].stockquantity);

            }
            fileVariable.Flush();
            fileVariable.Close();
        }
        static void readDatacrud(string path, List<departmental> s, ref string Productname, ref string Productcatagory, ref float Price, ref int Stockquantity)
        {
            if (File.Exists(path))
            {
                StreamReader fileVariable = new StreamReader(path);
                string record;
                while ((record = fileVariable.ReadLine()) != null)
                {
                    departmental info = new departmental(ref Productname, ref Productcatagory, ref Price, ref Stockquantity);
                    info.productname = parseData(record, 1);
                    info.productcatagory = parseData(record, 2);
                    info.price = float.Parse(parseData(record, 3));
                    info.stockquantity = int.Parse(parseData(record, 4));
                    s.Add(info);
                }
                fileVariable.Close();
            }
            else
            {
                Console.WriteLine("Not Exists");
            }
        }
        static string parseData(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int x = 0; x < record.Length; x++)
            {
                if (record[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[x];
                }
            }         
            return item;
        }
        static int menu()
        {
            int option;
            Console.WriteLine("1. SignIn");
            Console.WriteLine("2. SignUp");
            Console.WriteLine("Enter Option");
            option = int.Parse(Console.ReadLine());
            return option;
        }
        static bool readData(string path1 , List<MUser> users)

        {
            if (File.Exists(path1))
            {
                StreamReader file = new StreamReader(path1);
                string record; 
                while ((record = file.ReadLine()) != null)
                {
                    
                    string name = parseData1(record, 1);
                    string password = parseData1(record, 2);
                    string role = parseData1(record, 3);
                    MUser user = new MUser(name, password, role);
                    storeDataInList(users, user);
                }
                file.Close();
                return true;
            }
            return false;
        }
        static string parseData1(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int x = 0; x < record.Length;
            x++)
            {
                if (record[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[x];
                }
            }
            return item;
        }
        static MUser takeInputWithoutRole()
        {
            Console.WriteLine("Enter Name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Password: ");
            string password = Console.ReadLine();
            if (name != null && password != null)
            {
                MUser user = new MUser(name, password);
                return user;
            }
            return null;

        }
        static MUser takeInputWithRole()
        {
            Console.WriteLine("Enter Name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Password: ");
            string password = Console.ReadLine();
            Console.WriteLine("Enter Role: ");
            string role = Console.ReadLine();
            if (name != null && password != null && role != null)
            {
                MUser user = new MUser(name, password, role);
                return user;
            }
            return null;

        }
        static void storeDataInList(List<MUser> users, MUser user)
        {
            users.Add(user);
        }
        static void storeDataInFile(string path1 , List<MUser> users)
        {
            StreamWriter file = new StreamWriter(path1);
           
            for (int i = 0; i < users.Count; i++)
            {
                file.WriteLine(users[i].name + "," + users[i].password + "," + users[i].role);
            }
            file.Flush();
            file.Close();

        }
        static MUser signIn(MUser user, List<MUser> users)
        {
            foreach (MUser storedUser in users)
            {
                if (user.name == storedUser.name && user.password == storedUser.password)
                {
                    return storedUser;
                }
            }
            return null;
        }
    }
}