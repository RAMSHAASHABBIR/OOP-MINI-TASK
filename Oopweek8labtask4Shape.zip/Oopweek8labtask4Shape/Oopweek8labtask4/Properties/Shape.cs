﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oopweek8labtask4.Properties
{
     class Shape
    {
        public virtual string getshape()
        {
            return "undefined";
        }
        public virtual double getarea()
        {
            return 0;
        }
        public virtual string toString(double area)
        {
            string s = "Shape is" + getshape() + area.ToString();
            return s;
        }
        public void print()
        {
            foreach (Shape i in ShapeDL.shapes)
            {

                Console.WriteLine("Shape is" + getshape() + getarea().ToString());
            }
        }
    }
}
