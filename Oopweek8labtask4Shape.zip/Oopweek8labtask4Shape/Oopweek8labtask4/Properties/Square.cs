﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oopweek8labtask4.Properties
{
     class Square : Shape
    {
        private int side;
        public Square(int side)
        {
            this.side = side; 
        }
        public override double getarea()
        {
            double area = side * side;
            return area;
        }
        public override string getshape()
        {
            return "square";
        }
        public override string toString(double area)
        {
            string s = "Shape is" + getshape() + area.ToString();
            return s;
        }
    }
}
