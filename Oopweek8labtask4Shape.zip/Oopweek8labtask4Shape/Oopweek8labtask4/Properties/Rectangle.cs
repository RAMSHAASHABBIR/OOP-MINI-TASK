﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oopweek8labtask4.Properties
{
    class Rectangle : Shape
    {
        private int length;
        private int width;
        public Rectangle(int length,int width)
        {
            this.length = length;
            this.width = width;
        }
        public override double getarea()
        {
            double area = length * width;
            return area;
        }
        public override string getshape()
        {
            return "rectangle";
        }
        public override string toString(double area)
        {
            string s = "Shape is" + getshape() + area.ToString();
            return s;
        }

    }
}
