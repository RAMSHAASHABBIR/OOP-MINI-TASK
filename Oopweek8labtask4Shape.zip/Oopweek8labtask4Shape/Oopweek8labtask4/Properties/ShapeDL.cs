﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oopweek8labtask4.Properties
{
    class ShapeDL
    {
        public static List<Shape> shapes = new List<Shape>();
        public void Addingstudenttolist(Square square)
        {
            shapes.Add(square);
        }
        public void Addingstudenttolist(Circle circle)
        {
            shapes.Add(circle);
        }
        public void Addingstudenttolist(Rectangle rectangle)
        {
            shapes.Add(rectangle);
        }
       
    }
}
