﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Oopweek8labtask4.Properties
{
     class Circle : Shape
    {
        private int radius;
        public Circle(int radius)
        {
            this.radius = radius;
        }
        public override double getarea()
        {
            double area = 2*3.14*radius;
            return area;
        }
        public override string getshape()
        {
            return "Circle";
        }
        public override string toString(double area)
        {
            string s = "Shape is" + getshape() + area.ToString();
            return s;
        }
    }
}
