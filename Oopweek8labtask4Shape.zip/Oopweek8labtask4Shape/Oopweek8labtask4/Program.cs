﻿using Oopweek8labtask4.Properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oopweek8labtask4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ShapeDL shapeDL = new ShapeDL();
            int choose = 0;
            do
            {
                select();
                choose = option();
                if (choose == 1)
                {
                    Square square = new Square(4);
                    double area = square.getarea();
                    shapeDL.Addingstudenttolist(square);
                }
                else if(choose == 2)
                {
                    Circle circle = new Circle(4);
                    double area = circle.getarea();
                    shapeDL.Addingstudenttolist(circle);
                }
                else if (choose == 3)
                {
                    Rectangle rectangle = new Rectangle(4,4);
                    double area = rectangle.getarea(); 
                    shapeDL.Addingstudenttolist(rectangle);
                }
                else if(choose == 4)
                {
                    Shape shape = new Shape();
                    shape.print();
                }
            }
            while (choose < 5);
        }
        static void select()
        {
            Console.WriteLine("if square");
            Console.WriteLine("if circle");
            Console.WriteLine("if rectangle");
            Console.WriteLine("print");
        }
        static int option()
        {
            int choose = int.Parse(Console.ReadLine());
            return choose;
        }
    }
}
