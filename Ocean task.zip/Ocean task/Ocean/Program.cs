﻿using Ocean.Properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ocean
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ShipDL shipDL = new ShipDL();
            ShipUI shipUI = new ShipUI();
            int choose = 0;
            do
            {
               choose =  Chosingoption();    
                if (choose == 1)
                {
                    Console.Clear();
                    Ship ship = shipUI.takeinput();
                    shipDL.addship(ship);
                } 
                else if(choose == 2)
                {
                    Console.Clear();
                    int shipno =  shipUI.Whichboat();
                    int check = shipDL.Showposition(shipno);
                    shipDL.Printship(check);
                }
                else if (choose == 3)
                {
                    Console.Clear();
                    int shipno = shipUI.Whichboat();
                    Ship Newship = shipUI.Changeshipposition(shipno);
                    shipDL.Changeposition(Newship,shipno);
                } 
            }
            while (choose < 4);
             
        }
         static int Chosingoption()
        {
            Console.WriteLine("ADD SHIP");
            Console.WriteLine("SHOW SHIP POSITION");
            Console.WriteLine("CHANGE POSITION");
            int option = int.Parse(Console.ReadLine());
            return option;
        }
    }
}
