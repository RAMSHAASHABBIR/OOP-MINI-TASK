﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ocean.Properties
{
     class Ship
    {
        public int Shipnumber;
        public Angle Longitudinal;
        public Angle Latitudinal; 
        public Ship(int shipnumber, int deegre1, int minute1, char direction1, int deegre2, int minute2, char direction2)
        {
            this.Shipnumber = shipnumber;
            Longitudinal = new Angle(deegre1,minute1,direction1);
            Latitudinal = new Angle(deegre2,minute2,direction2);
            
        }
    }
}
