﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ocean.Properties
{
     class ShipDL
    {
        static List<Ship> Shipinfo = new List<Ship>();
        public void addship(Ship ship)
        {
            Shipinfo.Add(ship);
        }
        public int Showposition(int shipno)
        {
           
                for (int j = 0; j < Shipinfo.Count(); j++)
                {
                    if ( shipno == Shipinfo[j].Shipnumber)
                    {
                        return j; 
                    }
                }
                return -1;
           
        } 
        public void Printship(int check)
        {
            Console.WriteLine("SHIP IS AT : {0} * {1} ' {2} ", Shipinfo[check].Longitudinal.Deegre, Shipinfo[check].Longitudinal.Minute, Shipinfo[check].Longitudinal.Direction);
            Console.WriteLine("SHIP IS AT : {0} * {1} ' {2} ", Shipinfo[check].Latitudinal.Deegre, Shipinfo[check].Latitudinal.Minute, Shipinfo[check].Latitudinal.Direction);
        }
        public void Newposition(int check, Ship Newship)
        {
            Shipinfo[check] = Newship;
        }
        public void Changeposition(Ship Newship, int shipno)
        {

            for (int j = 0; j < Shipinfo.Count(); j++)
            {
                if (shipno == Shipinfo[j].Shipnumber)
                {
                    Shipinfo[j] = Newship;
                   
                }
            }
        }
    }
}
 