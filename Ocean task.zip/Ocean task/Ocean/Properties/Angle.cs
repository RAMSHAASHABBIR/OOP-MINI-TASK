﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ocean.Properties
{
    class Angle
    {
        public int Deegre;
        public int Minute;
        public char Direction;
        public Angle(int deegre,int minute,char direction)
        {          
            this.Deegre = deegre;
            this.Minute = minute;
            this.Direction = direction;
        }
    }
}
