﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ocean.Properties
{
    class ShipUI
    {
        public Ship takeinput()
        {
            Console.WriteLine("ENTER SHIP NUMBER");
            int shipno = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER SHIP LONGITUDINAL DEEGRE");
            int longitudedeegre = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER SHIP LONGITUDINAL MINUTE");
            int longitudeminute = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER SHIP LONGITUDINAL DIRECTION");
            char longitudedirection = char.Parse(Console.ReadLine());
            Console.WriteLine("ENTER SHIP LATITUDINAL DEEGRE");
            int latitudedeegre = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER SHIP LATITUDINAL MINUTE");
            int latitudeminute = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER SHIP LATITUDINAL DIRECTION");
            char latitudedirection = char.Parse(Console.ReadLine());
            Ship ship = new Ship(shipno, longitudedeegre, longitudeminute, longitudedirection, latitudedeegre, latitudeminute, latitudedirection);
            return ship;
        }
        public int Whichboat()

        {
            Console.WriteLine("ENTER SHIP NUMBER");
            int shipno = int.Parse(Console.ReadLine());
            return shipno;
        }
       public Ship Changeshipposition(int shipno)
        {
            Console.WriteLine("ENTER SHIP LONGITUDINAL DEEGRE");
            int longitudedeegre = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER SHIP LONGITUDINAL MINUTE");
            int longitudeminute = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER SHIP LONGITUDINAL DIRECTION");
            char longitudedirection = char.Parse(Console.ReadLine());
            Console.WriteLine("ENTER SHIP LATITUDINAL DEEGRE");
            int latitudedeegre = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER SHIP LATITUDINAL MINUTE");
            int latitudeminute = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER SHIP LATITUDINAL DIRECTION");
            char latitudedirection = char.Parse(Console.ReadLine());
            Ship ship = new Ship(shipno, longitudedeegre, longitudeminute, longitudedirection, latitudedeegre, latitudeminute, latitudedirection);
            return ship;
        }
    }
}
